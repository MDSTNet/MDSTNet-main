from criterion.nll_loss import nll_loss, CrossEntropyLoss, MSELoss
__all__ =[
    nll_loss,
    CrossEntropyLoss,
    MSELoss
]